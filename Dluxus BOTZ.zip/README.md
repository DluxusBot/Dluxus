Albedo BOT 
SC ORI WH MODS DEV
 RECODE ZENS


<a href="https://visitor-badge.glitch.me/badge?page_id=RaaaGH/Albedo-BOT"><img title="Visitor" src="https://visitor-badge.glitch.me/badge?page_id=RaaaGH/Albedo-BOT"></a>
